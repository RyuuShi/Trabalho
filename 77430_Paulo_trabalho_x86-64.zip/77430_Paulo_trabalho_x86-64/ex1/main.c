#include <stdio.h>

int OrdenaCres(int*,int*, int*);

int main() {

      int a = 1;
      int b = 3;
      int c = 2;

      OrdenaCres(&a,&b,&c);
      printf("%d, %d, %d",a,b,c);
}
