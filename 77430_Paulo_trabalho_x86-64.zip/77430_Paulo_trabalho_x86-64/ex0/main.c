#include <stdio.h>

int Menor(int, int);

int main() {

 	int a = 20;
 	int b = 10;	
        printf("menor valor entre %d e %d : %d",a,b,Menor(20,10));   
        return 0;
}	
