#include <stdio.h>

long long int mul(long int, long int);


long int mul2(int a, int b) {

int  sign = 0; 
if(a < 0) {
    int temp = temp >> 31;
    a = (a ^ temp)-temp;
    sign = 1;
}

int result = 0;
while(a > 0) {
    result +=  b;
    a--;
}

return result;

if(sign)
    result =  -result;

}
    
int main() {  
  
    int a = -3;
    int b = 15000; 	
    printf("%d x %d = %lld",a,b,mul(a,b));

return 0;
}
