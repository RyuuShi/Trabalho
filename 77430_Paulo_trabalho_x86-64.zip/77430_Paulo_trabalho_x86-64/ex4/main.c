#include <stdio.h>

int mod(int, int);

int main() {
     int a = 33;
     int b = 5;	
    printf("%d mod %d = %d",a,b,mod(33,7));

    return 0;

}
