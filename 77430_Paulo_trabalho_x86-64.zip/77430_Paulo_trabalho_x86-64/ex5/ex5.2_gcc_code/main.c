#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <x86intrin.h>

#define SIZE 10000000

long long int SumVector(int *a, size_t size) {
	int i;
	long long int sum = 0;
	for(i = 0; i < size; i++)
		sum += a[i];
	return sum;
}


int main() {


    int *array;
    if((array = (int*)_mm_malloc(sizeof(int[SIZE]),16)) == NULL) {
        fprintf(stderr,"Error : Cannot allocate memory.");
        return 1;
    }


     __m128i x = _mm_setr_epi32(1,2,3,4);
    __m128i y = _mm_setr_epi32(4,4,4,4);

    __m128i m  = _mm_load_si128(&x);
    __m128i m2 = _mm_load_si128(&y);

    int i;

    for(i = 0; i < SIZE; i+=4) {
        _mm_store_si128((__m128i*)&array[i],m);
        m =  _mm_add_epi32(m,m2);
    }   
    
    uint64_t t1 = __rdtsc();
    
    long long sum = SumVector(array, SIZE);
      
    uint64_t t2 = __rdtsc();
	
    printf("Somatório : %lld\ntempo em clocks : %llu\n",sum,(t2-t1));
  
    _mm_free(array);
   
    return 0;
}  
        
