#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <x86intrin.h>

#define SIZE 10000000

void SubtractVector(float * A, float *B, float *C, size_t size) {

	int i;
	for(i = 0; i < size; i++)
		C[i] = A[i] - B[i];
	
}

int main() {


    float *A;
    if((A = (float*)_mm_malloc(sizeof(int[SIZE]),32)) == NULL) {
        fprintf(stderr,"Error : Cannot allocate memory.");
        return 1;
    }

   static const float    __attribute__ ((aligned (32))) x[] = {1.0f,2.0f,3.0f,4.0f,5.0f,6.0f,7.0f,8.0};
   static const float    __attribute__ ((aligned (32))) y = 4.0;
   
    __m256 m  = _mm256_load_ps(x);
    __m256 m2 = _mm256_broadcast_ss(&y);
   
    int i;
    for(i = 0; i < SIZE; i+=8) {
        _mm256_store_ps(&A[i],m);
        m = _mm256_add_ps(m,m2);
    }
       
   float *C;
    if((C = (float*)_mm_malloc(sizeof(int[SIZE]),32)) == NULL) {
        fprintf(stderr,"Error : Cannot allocate memory.");
        return 1;
    }

   uint64_t t1 = __rdtsc();
    
   SubtractVector(A,A,C,SIZE);
      
    uint64_t t2 = __rdtsc();
	
    printf("tempo em clocks : %llu\n",(t2-t1));
  
    _mm_free(A);
    _mm_free(C);
   
    return 0;
}  
        






    
    
